
"use strict";

let Register = require('./Register.js');
let inputs_outputs = require('./inputs_outputs.js');
let MotorPID = require('./MotorPID.js');
let named_inputs_outputs = require('./named_inputs_outputs.js');
let QueryAlarm = require('./QueryAlarm.js');
let State = require('./State.js');
let ElevatorAction = require('./ElevatorAction.js');
let encoders = require('./encoders.js');
let Cartesian_Euler_pose = require('./Cartesian_Euler_pose.js');
let alarmsmonitor = require('./alarmsmonitor.js');
let RobotnikMotorsStatus = require('./RobotnikMotorsStatus.js');
let Interfaces = require('./Interfaces.js');
let BatteryDockingStatusStamped = require('./BatteryDockingStatusStamped.js');
let BoolArray = require('./BoolArray.js');
let Axis = require('./Axis.js');
let Pose2DArray = require('./Pose2DArray.js');
let InverterStatus = require('./InverterStatus.js');
let MotorsStatus = require('./MotorsStatus.js');
let alarmmonitor = require('./alarmmonitor.js');
let MotorHeadingOffset = require('./MotorHeadingOffset.js');
let named_input_output = require('./named_input_output.js');
let Data = require('./Data.js');
let MotorStatus = require('./MotorStatus.js');
let BatteryDockingStatus = require('./BatteryDockingStatus.js');
let LaserMode = require('./LaserMode.js');
let ptz = require('./ptz.js');
let PresenceSensorArray = require('./PresenceSensorArray.js');
let SafetyModuleStatus = require('./SafetyModuleStatus.js');
let AlarmSensor = require('./AlarmSensor.js');
let Pose2DStamped = require('./Pose2DStamped.js');
let ElevatorStatus = require('./ElevatorStatus.js');
let SubState = require('./SubState.js');
let LaserStatus = require('./LaserStatus.js');
let Alarms = require('./Alarms.js');
let Registers = require('./Registers.js');
let PresenceSensor = require('./PresenceSensor.js');
let MotorsStatusDifferential = require('./MotorsStatusDifferential.js');
let ReturnMessage = require('./ReturnMessage.js');
let BatteryStatus = require('./BatteryStatus.js');
let BatteryStatusStamped = require('./BatteryStatusStamped.js');
let StringArray = require('./StringArray.js');
let SetElevatorGoal = require('./SetElevatorGoal.js');
let SetElevatorFeedback = require('./SetElevatorFeedback.js');
let SetElevatorAction = require('./SetElevatorAction.js');
let SetElevatorActionFeedback = require('./SetElevatorActionFeedback.js');
let SetElevatorActionGoal = require('./SetElevatorActionGoal.js');
let SetElevatorResult = require('./SetElevatorResult.js');
let SetElevatorActionResult = require('./SetElevatorActionResult.js');

module.exports = {
  Register: Register,
  inputs_outputs: inputs_outputs,
  MotorPID: MotorPID,
  named_inputs_outputs: named_inputs_outputs,
  QueryAlarm: QueryAlarm,
  State: State,
  ElevatorAction: ElevatorAction,
  encoders: encoders,
  Cartesian_Euler_pose: Cartesian_Euler_pose,
  alarmsmonitor: alarmsmonitor,
  RobotnikMotorsStatus: RobotnikMotorsStatus,
  Interfaces: Interfaces,
  BatteryDockingStatusStamped: BatteryDockingStatusStamped,
  BoolArray: BoolArray,
  Axis: Axis,
  Pose2DArray: Pose2DArray,
  InverterStatus: InverterStatus,
  MotorsStatus: MotorsStatus,
  alarmmonitor: alarmmonitor,
  MotorHeadingOffset: MotorHeadingOffset,
  named_input_output: named_input_output,
  Data: Data,
  MotorStatus: MotorStatus,
  BatteryDockingStatus: BatteryDockingStatus,
  LaserMode: LaserMode,
  ptz: ptz,
  PresenceSensorArray: PresenceSensorArray,
  SafetyModuleStatus: SafetyModuleStatus,
  AlarmSensor: AlarmSensor,
  Pose2DStamped: Pose2DStamped,
  ElevatorStatus: ElevatorStatus,
  SubState: SubState,
  LaserStatus: LaserStatus,
  Alarms: Alarms,
  Registers: Registers,
  PresenceSensor: PresenceSensor,
  MotorsStatusDifferential: MotorsStatusDifferential,
  ReturnMessage: ReturnMessage,
  BatteryStatus: BatteryStatus,
  BatteryStatusStamped: BatteryStatusStamped,
  StringArray: StringArray,
  SetElevatorGoal: SetElevatorGoal,
  SetElevatorFeedback: SetElevatorFeedback,
  SetElevatorAction: SetElevatorAction,
  SetElevatorActionFeedback: SetElevatorActionFeedback,
  SetElevatorActionGoal: SetElevatorActionGoal,
  SetElevatorResult: SetElevatorResult,
  SetElevatorActionResult: SetElevatorActionResult,
};
