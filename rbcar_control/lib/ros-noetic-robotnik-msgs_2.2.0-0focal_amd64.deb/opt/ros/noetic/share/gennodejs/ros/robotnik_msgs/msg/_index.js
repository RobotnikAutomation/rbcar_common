
"use strict";

let ReturnMessage = require('./ReturnMessage.js');
let BatteryDockingStatus = require('./BatteryDockingStatus.js');
let OdomCalibrationStatusStamped = require('./OdomCalibrationStatusStamped.js');
let PantiltStatusStamped = require('./PantiltStatusStamped.js');
let PresenceSensorArray = require('./PresenceSensorArray.js');
let State = require('./State.js');
let ElevatorAction = require('./ElevatorAction.js');
let MotorsStatus = require('./MotorsStatus.js');
let encoders = require('./encoders.js');
let MotorReferenceValue = require('./MotorReferenceValue.js');
let WatchdogStatus = require('./WatchdogStatus.js');
let OdomManualCalibrationStatus = require('./OdomManualCalibrationStatus.js');
let alarmsmonitor = require('./alarmsmonitor.js');
let PresenceSensor = require('./PresenceSensor.js');
let LaserMode = require('./LaserMode.js');
let QueryAlarm = require('./QueryAlarm.js');
let OdomManualCalibrationStatusStamped = require('./OdomManualCalibrationStatusStamped.js');
let MotorCurrent = require('./MotorCurrent.js');
let InverterStatus = require('./InverterStatus.js');
let Alarms = require('./Alarms.js');
let StringStamped = require('./StringStamped.js');
let SubState = require('./SubState.js');
let named_input_output = require('./named_input_output.js');
let MotorReferenceValueArray = require('./MotorReferenceValueArray.js');
let LaserStatus = require('./LaserStatus.js');
let OdomCalibrationStatus = require('./OdomCalibrationStatus.js');
let BatteryDockingStatusStamped = require('./BatteryDockingStatusStamped.js');
let SafetyModuleStatus = require('./SafetyModuleStatus.js');
let MotorPID = require('./MotorPID.js');
let ArmStatus = require('./ArmStatus.js');
let MotorHeadingOffset = require('./MotorHeadingOffset.js');
let Cartesian_Euler_pose = require('./Cartesian_Euler_pose.js');
let BatteryStatusStamped = require('./BatteryStatusStamped.js');
let AlarmSensor = require('./AlarmSensor.js');
let MotorsStatusDifferential = require('./MotorsStatusDifferential.js');
let ElevatorStatus = require('./ElevatorStatus.js');
let Registers = require('./Registers.js');
let ptz = require('./ptz.js');
let inputs_outputs = require('./inputs_outputs.js');
let Pose2DStamped = require('./Pose2DStamped.js');
let BatteryStatus = require('./BatteryStatus.js');
let named_inputs_outputs = require('./named_inputs_outputs.js');
let MotorStatus = require('./MotorStatus.js');
let BoolArray = require('./BoolArray.js');
let Interfaces = require('./Interfaces.js');
let WatchdogStatusArray = require('./WatchdogStatusArray.js');
let RecordStatus = require('./RecordStatus.js');
let Data = require('./Data.js');
let RobotnikMotorsStatus = require('./RobotnikMotorsStatus.js');
let Pose2DArray = require('./Pose2DArray.js');
let Register = require('./Register.js');
let Axis = require('./Axis.js');
let PantiltStatus = require('./PantiltStatus.js');
let alarmmonitor = require('./alarmmonitor.js');
let StringArray = require('./StringArray.js');
let SetElevatorAction = require('./SetElevatorAction.js');
let SetElevatorGoal = require('./SetElevatorGoal.js');
let SetElevatorActionResult = require('./SetElevatorActionResult.js');
let SetElevatorActionFeedback = require('./SetElevatorActionFeedback.js');
let SetElevatorFeedback = require('./SetElevatorFeedback.js');
let SetElevatorResult = require('./SetElevatorResult.js');
let SetElevatorActionGoal = require('./SetElevatorActionGoal.js');

module.exports = {
  ReturnMessage: ReturnMessage,
  BatteryDockingStatus: BatteryDockingStatus,
  OdomCalibrationStatusStamped: OdomCalibrationStatusStamped,
  PantiltStatusStamped: PantiltStatusStamped,
  PresenceSensorArray: PresenceSensorArray,
  State: State,
  ElevatorAction: ElevatorAction,
  MotorsStatus: MotorsStatus,
  encoders: encoders,
  MotorReferenceValue: MotorReferenceValue,
  WatchdogStatus: WatchdogStatus,
  OdomManualCalibrationStatus: OdomManualCalibrationStatus,
  alarmsmonitor: alarmsmonitor,
  PresenceSensor: PresenceSensor,
  LaserMode: LaserMode,
  QueryAlarm: QueryAlarm,
  OdomManualCalibrationStatusStamped: OdomManualCalibrationStatusStamped,
  MotorCurrent: MotorCurrent,
  InverterStatus: InverterStatus,
  Alarms: Alarms,
  StringStamped: StringStamped,
  SubState: SubState,
  named_input_output: named_input_output,
  MotorReferenceValueArray: MotorReferenceValueArray,
  LaserStatus: LaserStatus,
  OdomCalibrationStatus: OdomCalibrationStatus,
  BatteryDockingStatusStamped: BatteryDockingStatusStamped,
  SafetyModuleStatus: SafetyModuleStatus,
  MotorPID: MotorPID,
  ArmStatus: ArmStatus,
  MotorHeadingOffset: MotorHeadingOffset,
  Cartesian_Euler_pose: Cartesian_Euler_pose,
  BatteryStatusStamped: BatteryStatusStamped,
  AlarmSensor: AlarmSensor,
  MotorsStatusDifferential: MotorsStatusDifferential,
  ElevatorStatus: ElevatorStatus,
  Registers: Registers,
  ptz: ptz,
  inputs_outputs: inputs_outputs,
  Pose2DStamped: Pose2DStamped,
  BatteryStatus: BatteryStatus,
  named_inputs_outputs: named_inputs_outputs,
  MotorStatus: MotorStatus,
  BoolArray: BoolArray,
  Interfaces: Interfaces,
  WatchdogStatusArray: WatchdogStatusArray,
  RecordStatus: RecordStatus,
  Data: Data,
  RobotnikMotorsStatus: RobotnikMotorsStatus,
  Pose2DArray: Pose2DArray,
  Register: Register,
  Axis: Axis,
  PantiltStatus: PantiltStatus,
  alarmmonitor: alarmmonitor,
  StringArray: StringArray,
  SetElevatorAction: SetElevatorAction,
  SetElevatorGoal: SetElevatorGoal,
  SetElevatorActionResult: SetElevatorActionResult,
  SetElevatorActionFeedback: SetElevatorActionFeedback,
  SetElevatorFeedback: SetElevatorFeedback,
  SetElevatorResult: SetElevatorResult,
  SetElevatorActionGoal: SetElevatorActionGoal,
};
