
"use strict";

let GetBool = require('./GetBool.js')
let SetByte = require('./SetByte.js')
let axis_record = require('./axis_record.js')
let set_float_value = require('./set_float_value.js')
let SetLaserMode = require('./SetLaserMode.js')
let set_modbus_register_bit = require('./set_modbus_register_bit.js')
let home = require('./home.js')
let SetTransform = require('./SetTransform.js')
let get_digital_input = require('./get_digital_input.js')
let set_ptz = require('./set_ptz.js')
let set_height = require('./set_height.js')
let SetElevator = require('./SetElevator.js')
let GetPTZ = require('./GetPTZ.js')
let SetInt16 = require('./SetInt16.js')
let ack_alarm = require('./ack_alarm.js')
let get_mode = require('./get_mode.js')
let set_digital_output = require('./set_digital_output.js')
let SetNamedDigitalOutput = require('./SetNamedDigitalOutput.js')
let SetBuzzer = require('./SetBuzzer.js')
let set_named_digital_output = require('./set_named_digital_output.js')
let SetMotorPID = require('./SetMotorPID.js')
let set_modbus_register = require('./set_modbus_register.js')
let enable_disable = require('./enable_disable.js')
let SetMotorStatus = require('./SetMotorStatus.js')
let GetMotorsHeadingOffset = require('./GetMotorsHeadingOffset.js')
let SetMotorMode = require('./SetMotorMode.js')
let QueryAlarms = require('./QueryAlarms.js')
let Record = require('./Record.js')
let get_alarms = require('./get_alarms.js')
let set_mode = require('./set_mode.js')
let InsertTask = require('./InsertTask.js')
let get_modbus_register = require('./get_modbus_register.js')
let SetEncoderTurns = require('./SetEncoderTurns.js')
let SetCurrent = require('./SetCurrent.js')
let ResetFromSubState = require('./ResetFromSubState.js')
let SetString = require('./SetString.js')
let GetPOI = require('./GetPOI.js')
let set_analog_output = require('./set_analog_output.js')
let set_CartesianEuler_pose = require('./set_CartesianEuler_pose.js')
let set_odometry = require('./set_odometry.js')

module.exports = {
  GetBool: GetBool,
  SetByte: SetByte,
  axis_record: axis_record,
  set_float_value: set_float_value,
  SetLaserMode: SetLaserMode,
  set_modbus_register_bit: set_modbus_register_bit,
  home: home,
  SetTransform: SetTransform,
  get_digital_input: get_digital_input,
  set_ptz: set_ptz,
  set_height: set_height,
  SetElevator: SetElevator,
  GetPTZ: GetPTZ,
  SetInt16: SetInt16,
  ack_alarm: ack_alarm,
  get_mode: get_mode,
  set_digital_output: set_digital_output,
  SetNamedDigitalOutput: SetNamedDigitalOutput,
  SetBuzzer: SetBuzzer,
  set_named_digital_output: set_named_digital_output,
  SetMotorPID: SetMotorPID,
  set_modbus_register: set_modbus_register,
  enable_disable: enable_disable,
  SetMotorStatus: SetMotorStatus,
  GetMotorsHeadingOffset: GetMotorsHeadingOffset,
  SetMotorMode: SetMotorMode,
  QueryAlarms: QueryAlarms,
  Record: Record,
  get_alarms: get_alarms,
  set_mode: set_mode,
  InsertTask: InsertTask,
  get_modbus_register: get_modbus_register,
  SetEncoderTurns: SetEncoderTurns,
  SetCurrent: SetCurrent,
  ResetFromSubState: ResetFromSubState,
  SetString: SetString,
  GetPOI: GetPOI,
  set_analog_output: set_analog_output,
  set_CartesianEuler_pose: set_CartesianEuler_pose,
  set_odometry: set_odometry,
};
